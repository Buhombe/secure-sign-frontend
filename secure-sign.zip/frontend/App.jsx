import { useEffect, BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Manage from './pages/Manage';
import Upload from './pages/Upload';
import ViewDocument from './pages/ViewDocument';
import SignDocument from './pages/SignDocument';
import PlaceFields from './pages/PlaceFields';
import AuditLog from './pages/AuditLog';
import Settings from './pages/Settings';
import VerifyEmail from './pages/VerifyEmail';
import ResetPassword from './pages/ResetPassword';
import Pricing from './pages/Pricing';

export default function App() {
  // FIX P2: Fetch CSRF token on app load — stored in cookie by server
  useEffect(() => {
    const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
    fetch(`${API}/auth/csrf-token`, { credentials: 'include' }).catch(() => {});
  }, []);

  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/sign/:id" element={<SignDocument />} />
          <Route path="/verify-email" element={<VerifyEmail />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/manage" element={<ProtectedRoute><Manage /></ProtectedRoute>} />
          <Route path="/upload" element={<ProtectedRoute><Upload /></ProtectedRoute>} />
          <Route path="/place-fields/:id" element={<ProtectedRoute><PlaceFields /></ProtectedRoute>} />
          <Route path="/document/:id" element={<ProtectedRoute><ViewDocument /></ProtectedRoute>} />
          <Route path="/audit" element={<ProtectedRoute><AuditLog /></ProtectedRoute>} />
          <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
